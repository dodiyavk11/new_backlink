const locale = {
  APPLICATIONS: 'Applications',
  EXAMPLE: 'Example',
  DASHBOARD: 'dashboard',
};

export default locale;
