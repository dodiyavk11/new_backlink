const locale = {
  TITLE: 'Örnek Sayfa',
};

export default locale;
