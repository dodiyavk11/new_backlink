const locale = {
  TITLE: 'Dashboard Page',
};

export default locale;
