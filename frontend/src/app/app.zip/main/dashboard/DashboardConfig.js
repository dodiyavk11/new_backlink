import i18next from 'i18next';

import en from './i18n/en';
import tr from './i18n/tr';
import ar from './i18n/ar';
import dashboardPage from './Dashboard';

i18next.addResourceBundle('en', 'dashboardPage', en);
i18next.addResourceBundle('tr', 'dashboardPage', tr);
i18next.addResourceBundle('ar', 'dashboardPage', ar);

const DashboardConfig = {
  settings: {
    layout: {
      config: {},
    },
  },
  routes: [
    {
      path: 'dashbord',
      element: <dashboardPage />,
    },
  ],
};

 export default DashboardConfig;

/**
 * Lazy load Example
 */

// import React from 'react';

// const Dashboard = lazy(() => import('./Dashboard'));

// const DashboardConfig = {
//   settings: {
//     layout: {
//       config: {},
//     },
//   },
//   routes: [
//     {
//       path: 'dashbord',
//       element: <Dashboard />,
//     },
//   ],
// };

// export default DashboardConfig;

